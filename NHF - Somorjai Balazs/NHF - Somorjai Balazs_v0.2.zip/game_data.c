#include "game_data.h"
#include <math.h>

GameData *InitGameData()
{
    GameData *pGameData = (GameData *)malloc( sizeof( GameData ) );

    pGameData->pFirstKnightPlayer1      = NULL;
    pGameData->pFirstKnightPlayer2      = NULL;
    pGameData->CannonBallPlayer1.bValid = false;
    pGameData->CannonBallPlayer2.bValid = false;
    pGameData->CannonAnglePlayer1       = M_PI / 6;
    pGameData->CannonAnglePlayer2       = 5 * M_PI / 6;

    //Improvements
    pGameData->iKnightSpawningHpPlayer1 = 100;
    pGameData->iKnightSpawningHpPlayer2 = 100;
    pGameData->iKnightDamagePlayer1 = 10;
    pGameData->iKnightDamagePlayer2 = 10;
    return pGameData;
}

void StepKnights( GameData *pGameData )
{
    for( Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1; pKnightPlayer1 != NULL; pKnightPlayer1 = pKnightPlayer1->pNextKnight )
    {
        if( GetCanKnightMove( pGameData, pKnightPlayer1 ) )
            pKnightPlayer1->iXPos += 1;
    }

    for( Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2; pKnightPlayer2 != NULL; pKnightPlayer2 = pKnightPlayer2->pNextKnight )
    {
        if( GetCanKnightMove( pGameData, pKnightPlayer2 ) )
            pKnightPlayer2->iXPos -= 1;
    }
}

void FightKnights( GameData *pGameData )
{
    Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1;
    Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2;
    if( pKnightPlayer1 == NULL || pKnightPlayer2 == NULL )
        return;

    int iPosKnight1 = pKnightPlayer1->iXPos;
    int iPosKnight2 = pKnightPlayer2->iXPos;
    if( iPosKnight2 - iPosKnight1 > KNIGHT_ADJACENCY )
        return;

    int iDamageDoneByPlayer1 = rand() % pGameData->iKnightDamagePlayer1;
    int iDamageDoneByPlayer2 = rand() % pGameData->iKnightDamagePlayer2;

    pKnightPlayer1->iHp -= iDamageDoneByPlayer2;
    if( pKnightPlayer1->iHp <= 0 )
    {
        pGameData->pFirstKnightPlayer1 = pGameData->pFirstKnightPlayer1->pNextKnight;
        if( pGameData->pFirstKnightPlayer1 != NULL )
            pGameData->pFirstKnightPlayer1->pPrevKnight = NULL;
        free( pKnightPlayer1 );
    }

    pKnightPlayer2->iHp -= iDamageDoneByPlayer1;
    if( pKnightPlayer2->iHp <= 0 )
    {
        pGameData->pFirstKnightPlayer2 = pGameData->pFirstKnightPlayer2->pNextKnight;
        if( pGameData->pFirstKnightPlayer2 != NULL )
            pGameData->pFirstKnightPlayer2->pPrevKnight = NULL;
        free( pKnightPlayer2 );
    }
}

void AddKnight( GameData *pGameData, EPlayer ePlayer )
{
    Knight *pKnight;
    if( ePlayer == PLAYER_1 )
        pKnight = pGameData->pFirstKnightPlayer1;
    else
        pKnight = pGameData->pFirstKnightPlayer2;

    if( pKnight == NULL )
    {
        if( ePlayer == PLAYER_1 )
            pGameData->pFirstKnightPlayer1 = _CreateKnight( pGameData, ePlayer, NULL );
        else
            pGameData->pFirstKnightPlayer2 = _CreateKnight( pGameData, ePlayer, NULL );

        return;
    }

    while( pKnight->pNextKnight != NULL )
        pKnight = pKnight->pNextKnight;

    _CreateKnight( pGameData, ePlayer, pKnight );
}

void MoveCannonUp( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
        pGameData->CannonAnglePlayer1 += 0.1;
    else
        pGameData->CannonAnglePlayer2 -= 0.1;
}

void MoveCannonDown( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
        pGameData->CannonAnglePlayer1 -= 0.1;
    else
        pGameData->CannonAnglePlayer2 += 0.1;
}

void FireCannon( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
    {
        if( pGameData->CannonBallPlayer1.bValid == true )
            return; // Cannon ball is already flying

        pGameData->CannonBallPlayer1.bValid         = true;
        pGameData->CannonBallPlayer1.vectorPos.dX   = 100 + cos( pGameData->CannonAnglePlayer1 ) * CANNON_LENGTH;
        pGameData->CannonBallPlayer1.vectorPos.dY   = 400 - sin( pGameData->CannonAnglePlayer1 ) * CANNON_LENGTH;
        pGameData->CannonBallPlayer1.vectorSpeed.dX =  cos( pGameData->CannonAnglePlayer1 ) * CANNONBALL_INITIAL_SPEED;
        pGameData->CannonBallPlayer1.vectorSpeed.dY = -sin( pGameData->CannonAnglePlayer1 ) * CANNONBALL_INITIAL_SPEED;
    }
    else
    {
        if( pGameData->CannonBallPlayer2.bValid == true )
            return; // Cannon ball is already flying

        pGameData->CannonBallPlayer2.bValid         = true;
        pGameData->CannonBallPlayer2.vectorPos.dX   = 900 + cos( pGameData->CannonAnglePlayer2 ) * CANNON_LENGTH;
        pGameData->CannonBallPlayer2.vectorPos.dY   = 400 - sin( pGameData->CannonAnglePlayer2 ) * CANNON_LENGTH;
        pGameData->CannonBallPlayer2.vectorSpeed.dX =  cos( pGameData->CannonAnglePlayer2 ) * CANNONBALL_INITIAL_SPEED;
        pGameData->CannonBallPlayer2.vectorSpeed.dY = -sin( pGameData->CannonAnglePlayer2 ) * CANNONBALL_INITIAL_SPEED;
    }
}

void MoveCannonBall( GameData *pGameData )
{
    if( pGameData->CannonBallPlayer1.bValid == true )
    {
        if( pGameData->CannonBallPlayer1.vectorPos.dY > 515 ) // Below ground
        {
            pGameData->CannonBallPlayer1.bValid = false;
        }
        else
        {
            pGameData->CannonBallPlayer1.vectorPos.dX   += pGameData->CannonBallPlayer1.vectorSpeed.dX;
            pGameData->CannonBallPlayer1.vectorPos.dY   += pGameData->CannonBallPlayer1.vectorSpeed.dY;
            pGameData->CannonBallPlayer1.vectorSpeed.dY += CANNONBALL_GRAVITY;
        }
    }

    if( pGameData->CannonBallPlayer2.bValid == true )
    {
        if( pGameData->CannonBallPlayer2.vectorPos.dY > 515 ) // Below ground
        {
            pGameData->CannonBallPlayer2.bValid = false;
        }
        else
        {
            pGameData->CannonBallPlayer2.vectorPos.dX   += pGameData->CannonBallPlayer2.vectorSpeed.dX;
            pGameData->CannonBallPlayer2.vectorPos.dY   += pGameData->CannonBallPlayer2.vectorSpeed.dY;
            pGameData->CannonBallPlayer2.vectorSpeed.dY += CANNONBALL_GRAVITY;
        }
    }
}

bool GetCanKnightMove( GameData *pGameData, Knight *pKnight )
{
    if( pKnight == NULL )
        return false;

    if( pKnight->ePlayer == PLAYER_1 )
    {
        if( pKnight == pGameData->pFirstKnightPlayer1 )
        {
            if( pGameData->pFirstKnightPlayer2 != NULL )
                if( pGameData->pFirstKnightPlayer2->iXPos - pGameData->pFirstKnightPlayer1->iXPos <= KNIGHT_ADJACENCY )
                    return false;
        }
        else if( pKnight->pPrevKnight != NULL )
        {
            if( pKnight->pPrevKnight->iXPos - pKnight->iXPos <= KNIGHT_ADJACENCY )
                return false;
        }
    }
    else
    {
        if( pKnight == pGameData->pFirstKnightPlayer2 )
        {
            if( pGameData->pFirstKnightPlayer1 != NULL )
                if( pGameData->pFirstKnightPlayer2->iXPos - pGameData->pFirstKnightPlayer1->iXPos <= KNIGHT_ADJACENCY )
                    return false;
        }
        else if( pKnight->pPrevKnight != NULL )
        {
            if( pKnight->iXPos - pKnight->pPrevKnight->iXPos <= KNIGHT_ADJACENCY )
                return false;
        }
    }

    return true;
}

Knight *_CreateKnight( GameData *pGameData, EPlayer ePlayer, Knight *pPrevKnight  )
{
    Knight *pKnightCreated = (Knight *)malloc( sizeof( Knight ) );
    pKnightCreated->pPrevKnight = pPrevKnight;
    pKnightCreated->pNextKnight = NULL;
    pKnightCreated->ePlayer     = ePlayer;

    if( pPrevKnight != NULL )
        pPrevKnight->pNextKnight = pKnightCreated;

    if( ePlayer == PLAYER_1 )
    {
        pKnightCreated->iXPos = 0;
        pKnightCreated->iHp   = pGameData->iKnightSpawningHpPlayer1;
    }
    else
    {
        pKnightCreated->iXPos = KNIGHT_PATH_LENGHT - 1;
        pKnightCreated->iHp   = pGameData->iKnightSpawningHpPlayer2;
    }

    return pKnightCreated;
}
