#include <SDL_image.h>
#include "gui.h"

#define CANNON_WIDTH       9
#define CANNONBALL_RADIUS  4

#define ROUND_DOUBLE_TO_INT( d ) (int)( d > 0 ? d + 0.5 : d - 0.5 )

GUIData *InitGUIData( SDL_Surface *pScreen )
{
    GUIData *pGUIData = (GUIData *)malloc( sizeof( GUIData ) );
    pGUIData->pScreen     = pScreen;
    pGUIData->pBackground = IMG_Load( "resources/hatter.png" );
    if ( pGUIData->pBackground == NULL )
    {
        fprintf(stderr, "Nem sikerult megnyitni az ablakot!\n");
        exit(1);
    }

    return pGUIData;
}

void RefreshGUI( GUIData *pGUIData, GameData *pGameData )
{
    SDL_Surface *pScreen = pGUIData->pScreen;

    SDL_BlitSurface( pGUIData->pBackground, NULL, pScreen, NULL );

    _PaintKnights( pScreen, pGameData->pFirstKnightPlayer1 );
    _PaintKnights( pScreen, pGameData->pFirstKnightPlayer2 );

    _PaintCannonBalls( pScreen, pGameData );
    _PaintCannons(     pScreen, pGameData );

    SDL_Flip(pScreen);
}

void _PaintKnights( SDL_Surface *pScreen, Knight *pFirstKnight )
{
    if( pFirstKnight == NULL )
        return;

    if( pFirstKnight->ePlayer == PLAYER_1 )
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
            boxRGBA( pScreen, pKnight->iXPos + 100, 475, pKnight->iXPos + 131, 515, 255, 0, 0, 255 );
    }
    else
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
            boxRGBA( pScreen, pKnight->iXPos + 100, 475, pKnight->iXPos + 131, 515, 0, 0, 255, 255 );
    }
}

void _PaintCannons( SDL_Surface *pScreen, GameData *pGameData )
{
    double dAngle1 = pGameData->CannonAnglePlayer1;
    thickLineRGBA( pScreen, 100, 400, 100 + cos( dAngle1 ) * CANNON_LENGTH, 400 - sin( dAngle1 ) * CANNON_LENGTH, CANNON_WIDTH, 0, 0, 0, 255 );

    double dAngle2 = pGameData->CannonAnglePlayer2;
    thickLineRGBA( pScreen, 900, 400, 900 + cos( dAngle2 ) * CANNON_LENGTH, 400 - sin( dAngle2 ) * CANNON_LENGTH, CANNON_WIDTH, 0, 0, 0, 255 );
}

void _PaintCannonBalls( SDL_Surface *pScreen, GameData *pGameData )
{
    if( pGameData->CannonBallPlayer1.bValid == true )
    {
        int iX = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer1.vectorPos.dX );
        int iY = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer1.vectorPos.dY );
        filledCircleRGBA( pScreen, iX, iY, CANNONBALL_RADIUS, 0, 0, 0, 255 );
    }

    if( pGameData->CannonBallPlayer2.bValid == true )
    {
        int iX = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer2.vectorPos.dX );
        int iY = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer2.vectorPos.dY );
        filledCircleRGBA( pScreen, iX, iY, CANNONBALL_RADIUS, 0, 0, 0, 255 );
    }
}
