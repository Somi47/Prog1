#include "game_data.h"
#include <math.h>

GameData *InitGameData()
{
    GameData *pGameData = (GameData *)malloc( sizeof( GameData ) );

    pGameData->iTickCount               = 0;
    pGameData->ePlayerWon               = PLAYER_NONE;
    pGameData->pFirstKnightPlayer1      = NULL;
    pGameData->pFirstKnightPlayer2      = NULL;
    pGameData->cannonBallPlayer1.bValid = false;
    pGameData->cannonBallPlayer2.bValid = false;
    pGameData->dCannonAnglePlayer1      = M_PI / 6;
    pGameData->dCannonAnglePlayer2      = 5 * M_PI / 6;
    pGameData->dLoadPercentPlayer1      = 0.0;
    pGameData->dLoadPercentPlayer2      = 0.0;
    pGameData->iGoldPlayer1             = 500;
    pGameData->iGoldPlayer2             = 500;

    //Improvements
    pGameData->iKnightSpawningHpPlayer1 = 1;
    pGameData->iKnightSpawningHpPlayer2 = 1;
    pGameData->iKnightDamagePlayer1     = 1;
    pGameData->iKnightDamagePlayer2     = 1;
    pGameData->iLoadTimePlayer1         = 1;
    pGameData->iLoadTimePlayer2         = 1;
    pGameData->iEconomyPlayer1          = 1;
    pGameData->iEconomyPlayer2          = 1;
    return pGameData;
}

void StepKnights( GameData *pGameData )
{
    for( Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1; pKnightPlayer1 != NULL; pKnightPlayer1 = pKnightPlayer1->pNextKnight )
    {
        if( GetCanKnightMove( pGameData, pKnightPlayer1 ) )
        {
            pKnightPlayer1->iXPos += 1;

            if( pGameData->iTickCount % 2 == 0 ) // new state applies in every second tick
            {
                if( pKnightPlayer1->eState >= S7 )
                    pKnightPlayer1->eState = S0;
                else
                    pKnightPlayer1->eState += 1;
            }
        }
    }

    for( Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2; pKnightPlayer2 != NULL; pKnightPlayer2 = pKnightPlayer2->pNextKnight )
    {
        if( GetCanKnightMove( pGameData, pKnightPlayer2 ) )
        {
            pKnightPlayer2->iXPos -= 1;

            if( pGameData->iTickCount % 2 == 0 ) // new state applies in every second tick
            {
                if( pKnightPlayer2->eState >= S7 )
                    pKnightPlayer2->eState = S0;
                else
                    pKnightPlayer2->eState += 1;
            }
        }
    }
}

void FightKnights( GameData *pGameData )
{
    Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1;
    Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2;
    if( pKnightPlayer1 == NULL || pKnightPlayer2 == NULL )
        return;

    int iPosKnight1 = pKnightPlayer1->iXPos;
    int iPosKnight2 = pKnightPlayer2->iXPos;
    if( iPosKnight2 - iPosKnight1 > KNIGHT_ADJACENCY )
        return;

    // State change to imitate fighting
        if( pKnightPlayer1->eState == S0 && pKnightPlayer2->eState == S0 )
        {
            pKnightPlayer1->eState = S4;
            pKnightPlayer2->eState = S4;
        }
        else
        {
            pKnightPlayer1->eState = S0;
            pKnightPlayer2->eState = S0;
        }

    int iDamageDoneByPlayer1 = rand() % ( pGameData->iKnightDamagePlayer1 * 10 );
    int iDamageDoneByPlayer2 = rand() % ( pGameData->iKnightDamagePlayer2 * 10 );

    pKnightPlayer1->iHp -= iDamageDoneByPlayer2;
    if( pKnightPlayer1->iHp <= 0 )
    {
        pGameData->pFirstKnightPlayer1 = pGameData->pFirstKnightPlayer1->pNextKnight;
        if( pGameData->pFirstKnightPlayer1 != NULL )
            pGameData->pFirstKnightPlayer1->pPrevKnight = NULL;
        free( pKnightPlayer1 );
    }

    pKnightPlayer2->iHp -= iDamageDoneByPlayer1;
    if( pKnightPlayer2->iHp <= 0 )
    {
        pGameData->pFirstKnightPlayer2 = pGameData->pFirstKnightPlayer2->pNextKnight;
        if( pGameData->pFirstKnightPlayer2 != NULL )
            pGameData->pFirstKnightPlayer2->pPrevKnight = NULL;
        free( pKnightPlayer2 );
    }
}

void AddKnight( GameData *pGameData, EPlayer ePlayer )
{
    Knight *pKnight;
    if( ePlayer == PLAYER_1 )
    {
        if( pGameData->iGoldPlayer1 < KNIGHT_PRICE )
            return;

        pKnight = pGameData->pFirstKnightPlayer1;
        pGameData->iGoldPlayer1 -= KNIGHT_PRICE;
    }
    else
    {
        if( pGameData->iGoldPlayer2 < KNIGHT_PRICE )
            return;

        pKnight = pGameData->pFirstKnightPlayer2;
        pGameData->iGoldPlayer2 -= KNIGHT_PRICE;
    }

    if( pKnight == NULL )
    {
        if( ePlayer == PLAYER_1 )
            pGameData->pFirstKnightPlayer1 = _CreateKnight( pGameData, ePlayer, NULL );
        else
            pGameData->pFirstKnightPlayer2 = _CreateKnight( pGameData, ePlayer, NULL );

        return;
    }

    while( pKnight->pNextKnight != NULL )
        pKnight = pKnight->pNextKnight;

    _CreateKnight( pGameData, ePlayer, pKnight );
}

void MoveCannonUp( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
        pGameData->dCannonAnglePlayer1 += 0.1;
    else
        pGameData->dCannonAnglePlayer2 -= 0.1;
}

void MoveCannonDown( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
        pGameData->dCannonAnglePlayer1 -= 0.1;
    else
        pGameData->dCannonAnglePlayer2 += 0.1;
}

void FireCannon( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
    {
        if( pGameData->cannonBallPlayer1.bValid == true )
            return; // Cannon ball is already flying

        if( pGameData->dLoadPercentPlayer1 < 1.0 )
            return;

        pGameData->dLoadPercentPlayer1 = 0.0;
        pGameData->cannonBallPlayer1.bValid         = true;
        pGameData->cannonBallPlayer1.vectorPos.dX   = 100 + cos( pGameData->dCannonAnglePlayer1 ) * CANNON_LENGTH;
        pGameData->cannonBallPlayer1.vectorPos.dY   = 400 - sin( pGameData->dCannonAnglePlayer1 ) * CANNON_LENGTH;
        pGameData->cannonBallPlayer1.vectorSpeed.dX =  cos( pGameData->dCannonAnglePlayer1 ) * CANNONBALL_INITIAL_SPEED;
        pGameData->cannonBallPlayer1.vectorSpeed.dY = -sin( pGameData->dCannonAnglePlayer1 ) * CANNONBALL_INITIAL_SPEED;
    }
    else
    {
        if( pGameData->cannonBallPlayer2.bValid == true )
            return; // Cannon ball is already flying

        if( pGameData->dLoadPercentPlayer2 < 1.0 )
            return;

        pGameData->dLoadPercentPlayer2 = 0.0;
        pGameData->cannonBallPlayer2.bValid         = true;
        pGameData->cannonBallPlayer2.vectorPos.dX   = 900 + cos( pGameData->dCannonAnglePlayer2 ) * CANNON_LENGTH;
        pGameData->cannonBallPlayer2.vectorPos.dY   = 400 - sin( pGameData->dCannonAnglePlayer2 ) * CANNON_LENGTH;
        pGameData->cannonBallPlayer2.vectorSpeed.dX =  cos( pGameData->dCannonAnglePlayer2 ) * CANNONBALL_INITIAL_SPEED;
        pGameData->cannonBallPlayer2.vectorSpeed.dY = -sin( pGameData->dCannonAnglePlayer2 ) * CANNONBALL_INITIAL_SPEED;
    }
}

void MoveCannonBall( GameData *pGameData )
{
    if( pGameData->cannonBallPlayer1.bValid == true )
    {
        if( pGameData->cannonBallPlayer1.vectorPos.dY > 515 ) // Below ground
        {
            pGameData->cannonBallPlayer1.bValid = false;
        }
        else
        {
            pGameData->cannonBallPlayer1.vectorPos.dX   += pGameData->cannonBallPlayer1.vectorSpeed.dX;
            pGameData->cannonBallPlayer1.vectorPos.dY   += pGameData->cannonBallPlayer1.vectorSpeed.dY;
            pGameData->cannonBallPlayer1.vectorSpeed.dY += CANNONBALL_GRAVITY;
        }
    }

    if( pGameData->cannonBallPlayer2.bValid == true )
    {
        if( pGameData->cannonBallPlayer2.vectorPos.dY > 515 ) // Below ground
        {
            pGameData->cannonBallPlayer2.bValid = false;
        }
        else
        {
            pGameData->cannonBallPlayer2.vectorPos.dX   += pGameData->cannonBallPlayer2.vectorSpeed.dX;
            pGameData->cannonBallPlayer2.vectorPos.dY   += pGameData->cannonBallPlayer2.vectorSpeed.dY;
            pGameData->cannonBallPlayer2.vectorSpeed.dY += CANNONBALL_GRAVITY;
        }
    }
}

void RegisterHit( GameData *pGameData )
{
    int iXPosCannonBall_1 = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer1.bValid ? pGameData->cannonBallPlayer1.vectorPos.dX : -1.0 );
    int iYPosCannonBall_1 = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer1.bValid ? pGameData->cannonBallPlayer1.vectorPos.dY : -1.0 );
    int iXPosCannonBall_2 = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer2.bValid ? pGameData->cannonBallPlayer2.vectorPos.dX : -1.0 );
    int iYPosCannonBall_2 = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer2.bValid ? pGameData->cannonBallPlayer2.vectorPos.dY : -1.0 );

    for( Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1; pKnightPlayer1 != NULL; pKnightPlayer1 = pKnightPlayer1->pNextKnight )
    {
        if( GetKnightHit( pKnightPlayer1, iXPosCannonBall_1, iYPosCannonBall_1 ) ||
            GetKnightHit( pKnightPlayer1, iXPosCannonBall_2, iYPosCannonBall_2 ) )
        {
            if( pKnightPlayer1->pPrevKnight != NULL )
                pKnightPlayer1->pPrevKnight->pNextKnight = pKnightPlayer1->pNextKnight;

            if( pKnightPlayer1->pNextKnight != NULL )
                pKnightPlayer1->pNextKnight->pPrevKnight = pKnightPlayer1->pPrevKnight;

            if( pKnightPlayer1 == pGameData->pFirstKnightPlayer1 )
                pGameData->pFirstKnightPlayer1 = pKnightPlayer1->pNextKnight;

            free( pKnightPlayer1 );
        }
    }

    for( Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2; pKnightPlayer2 != NULL; pKnightPlayer2 = pKnightPlayer2->pNextKnight )
    {
        if( GetKnightHit( pKnightPlayer2, iXPosCannonBall_1, iYPosCannonBall_1 ) ||
            GetKnightHit( pKnightPlayer2, iXPosCannonBall_2, iYPosCannonBall_2 ) )
        {
            if( pKnightPlayer2->pPrevKnight != NULL )
                pKnightPlayer2->pPrevKnight->pNextKnight = pKnightPlayer2->pNextKnight;

            if( pKnightPlayer2->pNextKnight != NULL )
                pKnightPlayer2->pNextKnight->pPrevKnight = pKnightPlayer2->pPrevKnight;

            if( pKnightPlayer2 == pGameData->pFirstKnightPlayer2 )
                pGameData->pFirstKnightPlayer2 = pKnightPlayer2->pNextKnight;

            free( pKnightPlayer2 );
        }
    }
}

void UpdateCannLoad( GameData *pGameData )
{
    pGameData->dLoadPercentPlayer1 += pGameData->iLoadTimePlayer1 * 0.001;
    pGameData->dLoadPercentPlayer2 += pGameData->iLoadTimePlayer2 * 0.001;

    if( pGameData->dLoadPercentPlayer1 > 1.0 )
        pGameData->dLoadPercentPlayer1 = 1.0;

    if( pGameData->dLoadPercentPlayer2 > 1.0 )
        pGameData->dLoadPercentPlayer2 = 1.0;
}

void CalculateIncome( GameData *pGameData )
{
    if( pGameData->iTickCount % 20 != 0 )
        return;

    pGameData->iGoldPlayer1 += pGameData->iEconomyPlayer1 * 50;
    pGameData->iGoldPlayer2 += pGameData->iEconomyPlayer2 * 50;
}

bool EvaluateWin( GameData *pGameData )
{
    bool bWonP1 = pGameData->pFirstKnightPlayer1 != NULL && pGameData->pFirstKnightPlayer1->iXPos >= KNIGHT_PATH_LENGHT;
    bool bWonP2 = pGameData->pFirstKnightPlayer2 != NULL && pGameData->pFirstKnightPlayer2->iXPos < 0;

    if( bWonP1 && bWonP2 )
        pGameData->ePlayerWon = PLAYER_BOTH;
    else if( bWonP1 )
        pGameData->ePlayerWon = PLAYER_1;
    else if( bWonP2 )
        pGameData->ePlayerWon = PLAYER_2;

    return bWonP1 || bWonP2;
}

int GetUpgradePrice( int iLevel )
{
    return pow( 2, iLevel - 1 ) * 100;
}

void UpgradeEconomy( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
    {
        int iPrice = GetUpgradePrice( pGameData->iEconomyPlayer1 );
        if( pGameData->iGoldPlayer1 < iPrice )
            return;

        pGameData->iEconomyPlayer1 += 1;
        pGameData->iGoldPlayer1    -= iPrice;
    }
    else
    {
        int iPrice = GetUpgradePrice( pGameData->iEconomyPlayer2 );
        if( pGameData->iGoldPlayer2 < iPrice )
            return;

        pGameData->iEconomyPlayer2 += 1;
        pGameData->iGoldPlayer2    -= iPrice;
    }
}

void UpgradeLoad( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
    {
        int iPrice = GetUpgradePrice( pGameData->iLoadTimePlayer1 );
        if( pGameData->iGoldPlayer1 < iPrice )
            return;

        pGameData->iLoadTimePlayer1 += 1;
        pGameData->iGoldPlayer1     -= iPrice;
    }
    else
    {
        int iPrice = GetUpgradePrice( pGameData->iLoadTimePlayer2 );
        if( pGameData->iGoldPlayer2 < iPrice )
            return;

        pGameData->iLoadTimePlayer2 += 1;
        pGameData->iGoldPlayer2     -= iPrice;
    }
}

void UpgradeSpawnHP( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
    {
        int iPrice = GetUpgradePrice( pGameData->iKnightSpawningHpPlayer1 );
        if( pGameData->iGoldPlayer1 < iPrice )
            return;

        pGameData->iKnightSpawningHpPlayer1 += 1;
        pGameData->iGoldPlayer1             -= iPrice;
    }
    else
    {
        int iPrice = GetUpgradePrice( pGameData->iKnightSpawningHpPlayer2 );
        if( pGameData->iGoldPlayer2 < iPrice )
            return;

        pGameData->iKnightSpawningHpPlayer2 += 1;
        pGameData->iGoldPlayer2             -= iPrice;
    }
}

void UpgradeDamage( GameData *pGameData, EPlayer ePlayer )
{
    if( ePlayer == PLAYER_1 )
    {
        int iPrice = GetUpgradePrice( pGameData->iKnightDamagePlayer1 );
        if( pGameData->iGoldPlayer1 < iPrice )
            return;

        pGameData->iKnightDamagePlayer1 += 1;
        pGameData->iGoldPlayer1         -= iPrice;
    }
    else
    {
        int iPrice = GetUpgradePrice( pGameData->iKnightDamagePlayer2 );
        if( pGameData->iGoldPlayer2 < iPrice )
            return;

        pGameData->iKnightDamagePlayer2 += 1;
        pGameData->iGoldPlayer2         -= iPrice;
    }
}

bool GetCanKnightMove( GameData *pGameData, Knight *pKnight )
{
    if( pKnight == NULL )
        return false;

    if( pKnight->ePlayer == PLAYER_1 )
    {
        if( pKnight == pGameData->pFirstKnightPlayer1 )
        {
            if( pGameData->pFirstKnightPlayer2 != NULL )
                if( pGameData->pFirstKnightPlayer2->iXPos - pGameData->pFirstKnightPlayer1->iXPos <= KNIGHT_ADJACENCY )
                    return false;
        }
        else if( pKnight->pPrevKnight != NULL )
        {
            if( pKnight->pPrevKnight->iXPos - pKnight->iXPos <= KNIGHT_ADJACENCY )
                return false;
        }
    }
    else
    {
        if( pKnight == pGameData->pFirstKnightPlayer2 )
        {
            if( pGameData->pFirstKnightPlayer1 != NULL )
                if( pGameData->pFirstKnightPlayer2->iXPos - pGameData->pFirstKnightPlayer1->iXPos <= KNIGHT_ADJACENCY )
                    return false;
        }
        else if( pKnight->pPrevKnight != NULL )
        {
            if( pKnight->iXPos - pKnight->pPrevKnight->iXPos <= KNIGHT_ADJACENCY )
                return false;
        }
    }

    return true;
}

Knight *_CreateKnight( GameData *pGameData, EPlayer ePlayer, Knight *pPrevKnight  )
{
    Knight *pKnightCreated = (Knight *)malloc( sizeof( Knight ) );
    pKnightCreated->pPrevKnight = pPrevKnight;
    pKnightCreated->pNextKnight = NULL;
    pKnightCreated->ePlayer     = ePlayer;
    pKnightCreated->eState      = S4;

    if( pPrevKnight != NULL )
        pPrevKnight->pNextKnight = pKnightCreated;

    if( ePlayer == PLAYER_1 )
    {
        pKnightCreated->iXPos = 0;
        pKnightCreated->iHp   = pGameData->iKnightSpawningHpPlayer1 * 100;
    }
    else
    {
        pKnightCreated->iXPos = KNIGHT_PATH_LENGHT - 1;
        pKnightCreated->iHp   = pGameData->iKnightSpawningHpPlayer2 * 100;
    }

    return pKnightCreated;
}

bool GetKnightHit( Knight *pKnight, int posXCannonBall, int posYCannonBall )
{
    if( posYCannonBall < 475 )
        return false;

    if( posYCannonBall > 515 )
        return false;

    if( posXCannonBall < pKnight->iXPos + 100 )
        return false;

    if( posXCannonBall > pKnight->iXPos + 131 )
        return false;

    return true;
}
