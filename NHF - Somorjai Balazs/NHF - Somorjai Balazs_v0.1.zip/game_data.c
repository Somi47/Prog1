#include "game_data.h"
#include <math.h>

#define KNIGHT_PATH_LENGHT 770

#define KNIGHT_ADJACENCY 40


GameData *InitGameData()
{
    GameData *pGameData = (GameData *)malloc( sizeof( GameData ) );

    pGameData->pFirstKnightPlayer1  = NULL;
    pGameData->pFirstKnightPlayer2  = NULL;
    pGameData->CannonBallPlayer1.iX = -1;
    pGameData->CannonBallPlayer1.iY = -1;
    pGameData->CannonBallPlayer2.iX = -1;
    pGameData->CannonBallPlayer2.iY = -1;
    pGameData->CannonAnglePlayer1   = M_PI / 4;
    pGameData->CannonAnglePlayer2   = M_PI - M_PI / 4;

    //Improvements
    pGameData->iKnightSpawningHpPlayer1 = 100;
    pGameData->iKnightSpawningHpPlayer2 = 100;
    pGameData->iKnightDamagePlayer1 = 10;
    pGameData->iKnightDamagePlayer2 = 10;
    return pGameData;
}

void StepKnights( GameData *pGameData )
{
    for( Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1; pKnightPlayer1 != NULL; pKnightPlayer1 = pKnightPlayer1->pNextKnight )
    {
        if( GetCanKnightMove( pGameData, pKnightPlayer1 ) )
            pKnightPlayer1->iXPos += 1;
    }

    for( Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2; pKnightPlayer2 != NULL; pKnightPlayer2 = pKnightPlayer2->pNextKnight )
    {
        if( GetCanKnightMove( pGameData, pKnightPlayer2 ) )
            pKnightPlayer2->iXPos -= 1;
    }
}

void FightKnights( GameData *pGameData )
{
    Knight *pKnightPlayer1 = pGameData->pFirstKnightPlayer1;
    Knight *pKnightPlayer2 = pGameData->pFirstKnightPlayer2;
    if( pKnightPlayer1 == NULL || pKnightPlayer2 == NULL )
        return;

    int iPosKnight1 = pKnightPlayer1->iXPos;
    int iPosKnight2 = pKnightPlayer2->iXPos;
    if( iPosKnight2 - iPosKnight1 > KNIGHT_ADJACENCY )
        return;

    int iDamageDoneByPlayer1 = rand() % pGameData->iKnightDamagePlayer1;
    int iDamageDoneByPlayer2 = rand() % pGameData->iKnightDamagePlayer2;

    pKnightPlayer1->iHp -= iDamageDoneByPlayer2;
    if( pKnightPlayer1->iHp <= 0 )
    {
        pGameData->pFirstKnightPlayer1 = pGameData->pFirstKnightPlayer1->pNextKnight;
        if( pGameData->pFirstKnightPlayer1 != NULL )
            pGameData->pFirstKnightPlayer1->pPrevKnight = NULL;
        free( pKnightPlayer1 );
    }

    pKnightPlayer2->iHp -= iDamageDoneByPlayer1;
    if( pKnightPlayer2->iHp <= 0 )
    {
        pGameData->pFirstKnightPlayer2 = pGameData->pFirstKnightPlayer2->pNextKnight;
        if( pGameData->pFirstKnightPlayer2 != NULL )
            pGameData->pFirstKnightPlayer2->pPrevKnight = NULL;
        free( pKnightPlayer2 );
    }
}

void AddKnight( GameData *pGameData, EPlayer ePlayer )
{
    Knight *pKnight;
    if( ePlayer == PLAYER_1 )
        pKnight = pGameData->pFirstKnightPlayer1;
    else
        pKnight = pGameData->pFirstKnightPlayer2;

    if( pKnight == NULL )
    {
        if( ePlayer == PLAYER_1 )
            pGameData->pFirstKnightPlayer1 = _CreateKnight( pGameData, ePlayer, NULL );
        else
            pGameData->pFirstKnightPlayer2 = _CreateKnight( pGameData, ePlayer, NULL );

        return;
    }

    while( pKnight->pNextKnight != NULL )
        pKnight = pKnight->pNextKnight;

    _CreateKnight( pGameData, ePlayer, pKnight );
}

bool GetCanKnightMove( GameData *pGameData, Knight *pKnight )
{
    if( pKnight == NULL )
        return false;

    if( pKnight->ePlayer == PLAYER_1 )
    {
        if( pKnight == pGameData->pFirstKnightPlayer1 )
        {
            if( pGameData->pFirstKnightPlayer2 != NULL )
                if( pGameData->pFirstKnightPlayer2->iXPos - pGameData->pFirstKnightPlayer1->iXPos <= KNIGHT_ADJACENCY )
                    return false;
        }
        else if( pKnight->pPrevKnight != NULL )
        {
            if( pKnight->pPrevKnight->iXPos - pKnight->iXPos <= KNIGHT_ADJACENCY )
                return false;
        }
    }
    else
    {
        if( pKnight == pGameData->pFirstKnightPlayer2 )
        {
            if( pGameData->pFirstKnightPlayer1 != NULL )
                if( pGameData->pFirstKnightPlayer2->iXPos - pGameData->pFirstKnightPlayer1->iXPos <= KNIGHT_ADJACENCY )
                    return false;
        }
        else if( pKnight->pPrevKnight != NULL )
        {
            if( pKnight->iXPos - pKnight->pPrevKnight->iXPos <= KNIGHT_ADJACENCY )
                return false;
        }
    }

    return true;
}

Knight *_CreateKnight( GameData *pGameData, EPlayer ePlayer, Knight *pPrevKnight  )
{
    Knight *pKnightCreated = (Knight *)malloc( sizeof( Knight ) );
    pKnightCreated->pPrevKnight = pPrevKnight;
    pKnightCreated->pNextKnight = NULL;
    pKnightCreated->ePlayer     = ePlayer;

    if( pPrevKnight != NULL )
        pPrevKnight->pNextKnight = pKnightCreated;

    if( ePlayer == PLAYER_1 )
    {
        pKnightCreated->iXPos = 0;
        pKnightCreated->iHp   = pGameData->iKnightSpawningHpPlayer1;
    }
    else
    {
        pKnightCreated->iXPos = KNIGHT_PATH_LENGHT - 1;
        pKnightCreated->iHp   = pGameData->iKnightSpawningHpPlayer2;
    }

    return pKnightCreated;
}
