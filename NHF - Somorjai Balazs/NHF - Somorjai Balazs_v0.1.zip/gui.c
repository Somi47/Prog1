#include <SDL_image.h>
#include "gui.h"

GUIData *InitGUIData( SDL_Surface *pScreen )
{
    GUIData *pGUIData = (GUIData *)malloc( sizeof( GUIData ) );
    pGUIData->pScreen     = pScreen;
    pGUIData->pBackground = IMG_Load( "resources/hatter.png" );
    if ( pGUIData->pBackground == NULL )
    {
        fprintf(stderr, "Nem sikerult megnyitni az ablakot!\n");
        exit(1);
    }

    return pGUIData;
}

void RefreshGUI( GUIData *pGUIData, GameData *pGameData )
{
    SDL_Surface *pScreen = pGUIData->pScreen;

    SDL_BlitSurface( pGUIData->pBackground, NULL, pScreen, NULL );

    _PaintKnights( pScreen, pGameData->pFirstKnightPlayer1 );
    _PaintKnights( pScreen, pGameData->pFirstKnightPlayer2 );

    SDL_Flip(pScreen);
}

void _PaintKnights( SDL_Surface *pScreen, Knight *pFirstKnight )
{
    if( pFirstKnight == NULL )
        return;

    if( pFirstKnight->ePlayer == PLAYER_1 )
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
            boxRGBA( pScreen, pKnight->iXPos + 100, 475, pKnight->iXPos + 131, 515, 255, 0, 0, 255 );
    }
    else
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
            boxRGBA( pScreen, pKnight->iXPos + 100, 475, pKnight->iXPos + 131, 515, 0, 0, 255, 255 );
    }
}
