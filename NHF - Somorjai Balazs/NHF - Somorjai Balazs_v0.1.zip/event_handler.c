#include "event_handler.h"

#define NOTUSED()

EventData *InitEventData()
{
    EventData *pEventData  = (EventData *)malloc( sizeof( EventData ) );
    pEventData->pLastEvent = NULL;
    pEventData->iTickCount = 0;
    return pEventData;
}

void HandleEvent( EventData *pEventData, SDL_Event *pEvent, GameData *pGameData )
{
    pEventData->pLastEvent = pEvent;

    switch (pEvent->type)
    {
        case SDL_KEYDOWN  : _HandleKeyEvent(   pEventData, pEvent, pGameData ); break;
        case SDL_USEREVENT: _HandleTimerEvent( pEventData, pEvent, pGameData ); break;
    }
    // TODO
}

bool UserTerminated( EventData *pEventData )
{
    if( pEventData->pLastEvent == NULL )
        return false;

    return pEventData->pLastEvent->type == SDL_QUIT;
}

void _HandleKeyEvent( EventData *pEventData, SDL_Event *pEvent, GameData *pGameData  )
{
    switch( pEvent->key.keysym.sym )
    {
        case SDLK_TAB  : AddKnight( pGameData, PLAYER_1 ); break;
        case SDLK_SPACE: AddKnight( pGameData, PLAYER_2 ); break;
        default: break;
    }
}

void _HandleTimerEvent( EventData *pEventData, SDL_Event *pEvent, GameData *pGameData )
{
    pEventData->iTickCount++;

    StepKnights(  pGameData );
    FightKnights( pGameData );
}
