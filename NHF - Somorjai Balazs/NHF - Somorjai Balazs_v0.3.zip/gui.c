#include <SDL_image.h>
#include "gui.h"

#define CANNON_WIDTH       9
#define CANNONBALL_RADIUS  4


GUIData *InitGUIData( SDL_Surface *pScreen )
{
    GUIData *pGUIData = (GUIData *)malloc( sizeof( GUIData ) );
    pGUIData->pScreen     = pScreen;
    pGUIData->pBackground = IMG_Load( "resources/hatter.png" );
    if ( pGUIData->pBackground == NULL )
    {
        fprintf(stderr, "Nem sikerult betolteni a hatteret!\n");
        exit(1);
    }

    for( int i=0; i<8; ++i )
    {
        char path1[20] = "resources/lovX.png";
        char path2[20] = "resources/lovXk.png";
        path1[13] = i + '1';
        path2[13] = i + '1';

        pGUIData->arrKnightP1[i] = IMG_Load( path1 );
        pGUIData->arrKnightP2[i] = IMG_Load( path2 );

        if( pGUIData->arrKnightP1[i] == NULL || pGUIData->arrKnightP2[i] == NULL )
        {
            fprintf(stderr, "Nem sikerult betolteni a lovagok kepet!\n");
            exit(1);
        }
    }

    return pGUIData;
}

void RefreshGUI( GUIData *pGUIData, GameData *pGameData )
{
    SDL_Surface *pScreen = pGUIData->pScreen;

    SDL_BlitSurface( pGUIData->pBackground, NULL, pScreen, NULL );

    _PaintKnights( pGUIData, pGameData->pFirstKnightPlayer1 );
    _PaintKnights( pGUIData, pGameData->pFirstKnightPlayer2 );

    _PaintCannonBalls( pScreen, pGameData );
    _PaintCannons(     pScreen, pGameData );

    SDL_Flip(pScreen);
}

void _PaintKnights( GUIData *pGUIData, Knight *pFirstKnight )
{
    if( pFirstKnight == NULL )
        return;

    if( pFirstKnight->ePlayer == PLAYER_1 )
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
        {
            SDL_Rect rect = { pKnight->iXPos + 100, 475, 31, 40 };
            SDL_BlitSurface( pGUIData->arrKnightP1[0], NULL, pGUIData->pScreen, &rect );
        }
    }
    else
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
        {
            SDL_Rect rect = { pKnight->iXPos + 100, 475, 31, 40 };
            SDL_BlitSurface( pGUIData->arrKnightP2[0], NULL, pGUIData->pScreen, &rect );
        }
    }
}

void _PaintCannons( SDL_Surface *pScreen, GameData *pGameData )
{
    double dAngle1 = pGameData->CannonAnglePlayer1;
    thickLineRGBA( pScreen, 100, 400, 100 + cos( dAngle1 ) * CANNON_LENGTH, 400 - sin( dAngle1 ) * CANNON_LENGTH, CANNON_WIDTH, 0, 0, 0, 255 );

    double dAngle2 = pGameData->CannonAnglePlayer2;
    thickLineRGBA( pScreen, 900, 400, 900 + cos( dAngle2 ) * CANNON_LENGTH, 400 - sin( dAngle2 ) * CANNON_LENGTH, CANNON_WIDTH, 0, 0, 0, 255 );
}

void _PaintCannonBalls( SDL_Surface *pScreen, GameData *pGameData )
{
    if( pGameData->CannonBallPlayer1.bValid == true )
    {
        int iX = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer1.vectorPos.dX );
        int iY = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer1.vectorPos.dY );
        filledCircleRGBA( pScreen, iX, iY, CANNONBALL_RADIUS, 0, 0, 0, 255 );
    }

    if( pGameData->CannonBallPlayer2.bValid == true )
    {
        int iX = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer2.vectorPos.dX );
        int iY = ROUND_DOUBLE_TO_INT( pGameData->CannonBallPlayer2.vectorPos.dY );
        filledCircleRGBA( pScreen, iX, iY, CANNONBALL_RADIUS, 0, 0, 0, 255 );
    }
}
