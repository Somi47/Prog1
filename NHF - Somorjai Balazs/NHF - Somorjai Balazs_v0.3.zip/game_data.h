#include <stdbool.h>
#include <SDL.h>
#include <SDL_gfxPrimitives.h>

#ifndef GAME_DATA_H_INCLUDED
#define GAME_DATA_H_INCLUDED

#define CANNON_LENGTH             60
#define KNIGHT_PATH_LENGHT       770
#define KNIGHT_ADJACENCY          30
#define CANNONBALL_INITIAL_SPEED  10.0
#define CANNONBALL_GRAVITY         0.2

#define ROUND_DOUBLE_TO_INT( d ) (int)( d > 0 ? d + 0.5 : d - 0.5 )

typedef enum{
    PLAYER_1,
    PLAYER_2
} EPlayer;

typedef struct{
    double dX, dY;
} Vector;

typedef struct{
    Vector vectorPos;
    Vector vectorSpeed;
    bool   bValid;
} CannonBall;

typedef struct Knight{
    EPlayer        ePlayer;
    int            iHp;
    int            iXPos;
    struct Knight *pPrevKnight;
    struct Knight *pNextKnight;
} Knight;

typedef struct GameData{
    int         iTickCount;
    Knight     *pFirstKnightPlayer1;
    Knight     *pFirstKnightPlayer2;
    CannonBall  CannonBallPlayer1;
    CannonBall  CannonBallPlayer2;
    double      CannonAnglePlayer1;
    double      CannonAnglePlayer2;


    //Improvements
    int iKnightSpawningHpPlayer1;
    int iKnightSpawningHpPlayer2;

    int iKnightDamagePlayer1;
    int iKnightDamagePlayer2;
} GameData;

GameData *InitGameData();
void      StepKnights(    GameData *pGameData );
void      FightKnights(   GameData *pGameData );
void      AddKnight(      GameData *pGameData, EPlayer ePlayer );
void      MoveCannonUp(   GameData *pGameData, EPlayer ePlayer );
void      MoveCannonDown( GameData *pGameData, EPlayer ePlayer );
void      FireCannon(     GameData *pGameData, EPlayer ePlayer );
void      MoveCannonBall( GameData *pGameData );
void      RegisterHit(    GameData *pGameData );

//private:
bool GetCanKnightMove( GameData *pGameData, Knight *pKnight );
Knight *_CreateKnight( GameData *pGameData, EPlayer ePlayer, Knight *pPrevKnight );
bool GetKnightHit( Knight *pKnight, int posXCannonBall, int posYCannonBall );

#endif // GAME_DATA_H_INCLUDED
