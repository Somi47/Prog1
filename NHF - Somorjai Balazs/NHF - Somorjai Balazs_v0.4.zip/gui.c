#include <SDL_image.h>
#include "gui.h"

#define CANNON_WIDTH       9
#define CANNONBALL_RADIUS  4

#define DATA_WINDOW_WIDTH  200
#define DATA_WINDOW_BOT    300

GUIData *InitGUIData( SDL_Surface *pScreen )
{
    GUIData *pGUIData = (GUIData *)malloc( sizeof( GUIData ) );
    pGUIData->pScreen     = pScreen;
    pGUIData->pBackground = IMG_Load( "resources/hatter.png" );
    if ( pGUIData->pBackground == NULL )
    {
        fprintf(stderr, "Nem sikerult betolteni a hatteret!\n");
        exit(1);
    }

    for( int i=0; i<8; ++i )
    {
        char path1[20] = "resources/lovX.png";
        char path2[20] = "resources/lovXk.png";
        path1[13] = i + '1';
        path2[13] = i + '1';

        pGUIData->arrKnightP1[i] = IMG_Load( path1 );
        pGUIData->arrKnightP2[i] = IMG_Load( path2 );

        if( pGUIData->arrKnightP1[i] == NULL || pGUIData->arrKnightP2[i] == NULL )
        {
            fprintf(stderr, "Nem sikerult betolteni a lovagok kepet!\n");
            exit(1);
        }
    }

    return pGUIData;
}

void RefreshGUI( GUIData *pGUIData, GameData *pGameData )
{
    SDL_Surface *pScreen = pGUIData->pScreen;

    SDL_BlitSurface( pGUIData->pBackground, NULL, pScreen, NULL );

    _PaintData( pScreen, pGameData );

    _PaintKnights( pGUIData, pGameData->pFirstKnightPlayer1 );
    _PaintKnights( pGUIData, pGameData->pFirstKnightPlayer2 );

    _PaintCannonBalls( pScreen, pGameData );
    _PaintCannons(     pScreen, pGameData );

    SDL_Flip(pScreen);
}

void _PaintData( SDL_Surface *pScreen, GameData *pGameData )
{
    // GOLD
    char strGoldP1[50];
    sprintf( strGoldP1, "Treasury: %9d gold", pGameData->iGoldPlayer1 );
    char strGoldP2[50];
    sprintf( strGoldP2, "Treasury: %9d gold", pGameData->iGoldPlayer2 );
    stringRGBA( pScreen, 0,                        DATA_WINDOW_BOT, strGoldP1, 0, 0, 0, 255 );
    stringRGBA( pScreen, 1000 - DATA_WINDOW_WIDTH, DATA_WINDOW_BOT, strGoldP2, 0, 0, 0, 255 );

    //LOAD
    char strLoadP1[50];
    sprintf( strLoadP1, "Cannon load: %6d %%", ROUND_DOUBLE_TO_INT( pGameData->dLoadPercentPlayer1 * 100 ) );
    char strLoadP2[50];
    sprintf( strLoadP2, "Cannon load: %6d %%", ROUND_DOUBLE_TO_INT( pGameData->dLoadPercentPlayer2 * 100 ) );
    stringRGBA( pScreen, 0,                        DATA_WINDOW_BOT - 8, strLoadP1, 0, 0, 0, 255 );
    stringRGBA( pScreen, 1000 - DATA_WINDOW_WIDTH, DATA_WINDOW_BOT - 8, strLoadP2, 0, 0, 0, 255 );

    //ECONOMY
    char strEconomyP1[50];
    int iEconomyLevelP1 = pGameData->iEconomyPlayer1;
    sprintf( strEconomyP1, "Economy %4d: %5d gold", iEconomyLevelP1, GetUpgradePrice( iEconomyLevelP1 ) );
    char strEconomyP2[50];
    int iEconomyLevelP2 = pGameData->iEconomyPlayer2;
    sprintf( strEconomyP2, "Economy %4d: %5d gold", iEconomyLevelP2, GetUpgradePrice( iEconomyLevelP2 ) );
    stringRGBA( pScreen, 0,                        DATA_WINDOW_BOT - 16, strEconomyP1, 0, 0, 0, 255 );
    stringRGBA( pScreen, 1000 - DATA_WINDOW_WIDTH, DATA_WINDOW_BOT - 16, strEconomyP2, 0, 0, 0, 255 );

    //LOAD_TIME
    char strLoadTimeP1[50];
    int iLoadTimeLevelP1 = pGameData->iLoadTimePlayer1;
    sprintf( strLoadTimeP1, "Load time %2d: %5d gold", iLoadTimeLevelP1, GetUpgradePrice( iLoadTimeLevelP1 ) );
    char strLoadTimeP2[50];
    int iLoadTimeLevelP2 = pGameData->iLoadTimePlayer2;
    sprintf( strLoadTimeP2, "Load time %2d: %5d gold", iLoadTimeLevelP2, GetUpgradePrice( iLoadTimeLevelP2 ) );
    stringRGBA( pScreen, 0,                        DATA_WINDOW_BOT - 24, strLoadTimeP1, 0, 0, 0, 255 );
    stringRGBA( pScreen, 1000 - DATA_WINDOW_WIDTH, DATA_WINDOW_BOT - 24, strLoadTimeP2, 0, 0, 0, 255 );

    //SPAWN_HP
    char strSawnHPP1[50];
    int iSawnHPLevelP1 = pGameData->iKnightSpawningHpPlayer1;
    sprintf( strSawnHPP1, "Spawn HP %3d: %5d gold", iSawnHPLevelP1, GetUpgradePrice( iSawnHPLevelP1 ) );
    char strSawnHPP2[50];
    int iSawnHPLevelP2 = pGameData->iKnightSpawningHpPlayer2;
    sprintf( strSawnHPP2, "Spawn HP %3d: %5d gold", iSawnHPLevelP2, GetUpgradePrice( iSawnHPLevelP2 ) );
    stringRGBA( pScreen, 0,                        DATA_WINDOW_BOT - 32, strSawnHPP1, 0, 0, 0, 255 );
    stringRGBA( pScreen, 1000 - DATA_WINDOW_WIDTH, DATA_WINDOW_BOT - 32, strSawnHPP2, 0, 0, 0, 255 );

    //DAMAGE
}

void _PaintKnights( GUIData *pGUIData, Knight *pFirstKnight )
{
    if( pFirstKnight == NULL )
        return;

    if( pFirstKnight->ePlayer == PLAYER_1 )
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
        {
            SDL_Rect rect = { pKnight->iXPos + 100, 475, 31, 40 };
            SDL_BlitSurface( pGUIData->arrKnightP1[0], NULL, pGUIData->pScreen, &rect );
        }
    }
    else
    {
        for( Knight *pKnight = pFirstKnight; pKnight != NULL; pKnight = pKnight->pNextKnight )
        {
            SDL_Rect rect = { pKnight->iXPos + 100, 475, 31, 40 };
            SDL_BlitSurface( pGUIData->arrKnightP2[0], NULL, pGUIData->pScreen, &rect );
        }
    }
}

void _PaintCannons( SDL_Surface *pScreen, GameData *pGameData )
{
    double dAngle1 = pGameData->dCannonAnglePlayer1;
    thickLineRGBA( pScreen, 100, 400, 100 + cos( dAngle1 ) * CANNON_LENGTH, 400 - sin( dAngle1 ) * CANNON_LENGTH, CANNON_WIDTH, 0, 0, 0, 255 );

    double dAngle2 = pGameData->dCannonAnglePlayer2;
    thickLineRGBA( pScreen, 900, 400, 900 + cos( dAngle2 ) * CANNON_LENGTH, 400 - sin( dAngle2 ) * CANNON_LENGTH, CANNON_WIDTH, 0, 0, 0, 255 );
}

void _PaintCannonBalls( SDL_Surface *pScreen, GameData *pGameData )
{
    if( pGameData->cannonBallPlayer1.bValid == true )
    {
        int iX = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer1.vectorPos.dX );
        int iY = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer1.vectorPos.dY );
        filledCircleRGBA( pScreen, iX, iY, CANNONBALL_RADIUS, 0, 0, 0, 255 );
    }

    if( pGameData->cannonBallPlayer2.bValid == true )
    {
        int iX = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer2.vectorPos.dX );
        int iY = ROUND_DOUBLE_TO_INT( pGameData->cannonBallPlayer2.vectorPos.dY );
        filledCircleRGBA( pScreen, iX, iY, CANNONBALL_RADIUS, 0, 0, 0, 255 );
    }
}
